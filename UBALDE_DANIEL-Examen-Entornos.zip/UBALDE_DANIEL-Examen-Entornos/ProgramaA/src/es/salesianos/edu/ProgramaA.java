package es.salesianos.edu;

import edu.salesianos.es.ProgramaB;

public class ProgramaA {
	ProgramaB programB = new ProgramaB();

	public static void main(String[] args) {

		System.out.println("Hello World");

	}

}