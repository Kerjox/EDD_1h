package es.salesianos.edu;

import java.util.Scanner;

public class TTLauncher {

	public static void main(String[] args) {

// extraer codigo en un método llamado initGame
		initGame();
// fin del metodo a extraer1

		do {
			playerMove(jugadorActual);

			if (hasWon(jugadorActual, filaActual, columnaActual)) {

				estadoActual = (jugadorActual == CRUZ) ? CRUZ_GANA : NADA_GANA;

			} else if (getPintar()) {

				estadoActual = PINTAR;
			}

// extraer codigo en un método llamado printBoard
			printBoard();
// fin del metodo a extraer

// extraer codigo en un método llamado printGameOver
			printGameOver();
// fin del metodo a extraer
			jugadorActual = (jugadorActual == CRUZ) ? NADA : CRUZ;

		} while (estadoActual == JUGANDO);
	}

	public static final int CRUZ = 1;

	public static final int CRUZ_GANA = 2;

	public static final int FILAS = 3, COLUMNAS = 3;

	public static final int JUGANDO = 0;

	public static final int NADA = 2;

	public static final int NADA_GANA = 3;

	public static final int PINTAR = 1;

	public static final int VACIO = 0;

	public static int[][] board = new int[FILAS][COLUMNAS];

	public static int estadoActual;

	public static int filaActual, columnaActual;

	public static Scanner in = new Scanner(System.in);

	public static int jugadorActual;

	private static void printGameOver() {

		if (estadoActual == CRUZ_GANA) {

			System.out.println("'X' won! Bye!");

		} else if (estadoActual == NADA_GANA) {

			System.out.println("'O' won! Bye!");

		} else if (estadoActual == PINTAR) {

			System.out.println("It's a Draw! Bye!");
		}
	}

	private static void printBoard() {

		for (int row = 0; row < FILAS; ++ row) {

			for (int col = 0; col < COLUMNAS; ++ col) {

				printCell(board[row][col]); // print each of the cells

				if (col != COLUMNAS - 1) {

					System.out.print("|"); // print vertical partition

				}
			}
			System.out.println();

			if (row != FILAS - 1) {

				System.out.println("------" + "-----"); // print horizontal

			}
		}

		System.out.println();
	}

	private static void initGame() {

		for (int row = 0; row < FILAS; ++ row) {

			for (int col = 0; col < COLUMNAS; ++ col) {

				board[row][col] = VACIO;

			}
		}

		estadoActual = JUGANDO;
		jugadorActual = CRUZ;
	}

	public static void playerMove(int semilla) {

		boolean validInput = false;

		do {
			if (semilla == CRUZ) {

				System.out.print("Player 'X', enter your move (row[1-3] column[1-3]): ");

			} else {

				System.out.print("Player 'O', enter your move (row[1-3] column[1-3]): ");

			}

			int row = in.nextInt() - 1;
			int col = in.nextInt() - 1;

			if (row >= 0 && row < FILAS && col >= 0 && col < COLUMNAS && board[row][col] == VACIO) {

				filaActual = row;
				columnaActual = col;
				board[filaActual][columnaActual] = semilla;
				validInput = true;

			} else {

				System.out.println("This move at (" + (row + 1) + "," + (col + 1) + ") is not valid. Try again...");
			}

		} while (! validInput);
	}

	public static void updateGame(int semilla, int filaActual, int columnaActual) {

		if (hasWon(semilla, filaActual, columnaActual)) { // check if winning move

			estadoActual = (semilla == CRUZ) ? CRUZ_GANA : NADA_GANA;

		} else if (getPintar()) { // check for draw

			estadoActual = PINTAR;
		}
	}

	public static boolean getPintar() {

		for (int row = 0; row < FILAS; ++ row) {

			for (int col = 0; col < COLUMNAS; ++ col) {

				if (board[row][col] == VACIO) {

					return false;
				}
			}
		}

		return true;
	}

	public static boolean hasWon(int semilla, int filaActual, int columnaActual) {

		return (board[filaActual][0] == semilla
				&& board[filaActual][1] == semilla && board[filaActual][2] == semilla
				|| board[0][columnaActual] == semilla
				&& board[1][columnaActual] == semilla && board[2][columnaActual] == semilla
				|| filaActual == columnaActual
				&& board[0][0] == semilla && board[1][1] == semilla && board[2][2] == semilla
				|| filaActual + columnaActual == 2
				&& board[0][2] == semilla && board[1][1] == semilla && board[2][0] == semilla);
	}


	public static void printCell(int contenido) {

		switch (contenido) {

			case VACIO -> System.out.print("   ");
			case NADA -> System.out.print(" O ");
			case CRUZ -> System.out.print(" X ");
		}
	}

}